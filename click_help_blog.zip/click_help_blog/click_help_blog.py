#!/usr/bin/env python
# coding: utf-8

# In[8]:


import time
import csv
import re
import requests
from time import sleep
from datetime import date
import pandas as pd
from bs4 import BeautifulSoup
from openpyxl import Workbook
import warnings
warnings.filterwarnings("ignore")

pages = 1

url = "https://clickhelp.com/clickhelp-technical-writing-blog/"

titles_list = []
keywords_list = []
published_date_list = []


while True:
    loc = {}
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    data_blog = soup.find_all('article', class_="Blog_post")
    
    for data in data_blog:
        title_element = data.find('div', class_="Blog_postHeader").find('a')
        if title_element:
            title = title_element.text.strip()
            loc['title'] = title
            titles_list.append(title)
            print('title:', title)


        footer_element = data.find('footer', class_="Blog_postFooter")
        if footer_element:
            keywords = footer_element.a.text.strip()
            loc['keyword'] = keywords
            print('keyword:', keywords)
            keywords_list.append(keywords)  # Append keywords to keywords_list


   
        published_dates = data.find('footer', class_="Blog_postFooter")
        published_date = published_dates.a.next_sibling.text.strip().replace("on","")
        loc['published_date'] = published_date
        published_date_list.append(published_date)
        print("published_date:", published_date)

    next_button = soup.find('nav', class_= "Blog_olderNewerLinks")
    max_pages = 51
    if next_button:
        page = next_button.a['href']
        url = "https://clickhelp.com" + page
        pages += 1
        if pages >=51:
            break
    else:
        break
    
    
# Create a DataFrame using pandas for storing the data into CSV and XLSX format.
df = pd.DataFrame({
    'Title': titles_list,
    'keyword':keywords_list,
    'Published Date': published_date_list
})

# Save to CSV
df.to_csv('click_help_blog.csv', index=False)

# Save to Excel
df.to_excel('click_help_blog.xlsx', index=False)

print("Data saved successfully.")

    
    
      


# In[ ]:




