#!/usr/bin/env python
# coding: utf-8

# In[2]:


import time
import csv
import re
import requests
from time import sleep
from datetime import date
import pandas as pd
from bs4 import BeautifulSoup
from openpyxl import Workbook
import warnings
warnings.filterwarnings("ignore")

pages = 1

url = "https://www.getguru.com/blog-all"

titles_list = []
authors_list = []
keywords_list = []
published_dates_list = []

while True:
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    blog_data = soup.find_all('div', class_= 'blog-body_item title-box')
    
    for data in blog_data:
        loc = {}
        
        titles = data.find('div', class_="blog-pinned_title text-style-2lines heading-title")
        if titles:
            title = titles.text.strip() 
            loc['title'] = title
            titles_list.append(title)
            print("Title:", title)
        
        authors = data.find('div', class_= "blog-top_author-name")
        if authors:
            author = authors.text.strip()
            loc['author'] = author
            authors_list.append(author)
            print("Author:", author)
        
        keywords = data.find('div', class_="blog_category-text")
        if keywords:
            keyword = keywords.text.strip()
            loc['keyword'] = keyword
            keywords_list.append(keyword)
            print("Keyword:", keyword)
        
        published_dates = data.find('div',class_= "blog_date-min")
        if published_dates:
            published_date = published_dates.text.strip()
            loc ['published_date'] = published_date
            published_dates_list.append(published_date)
            print("Published_date:", published_date)
            
   
    next_button = soup.find('a', class_= "w-pagination-next blog-pagination_button-next")
    if next_button:
        page = next_button['href']
        url = "https://www.getguru.com/blog-all" + page
        pages += 1
    else:
        break
# Create a DataFrame using pandas for storing the data into CSV and XLSX format.
df = pd.DataFrame({
    'Title': titles_list,
    'Author': authors_list,
    'keyword':keywords_list,
    'Published Date': published_dates_list
})

# Save to CSV
df.to_csv('guru_blog.csv', index=False)

# Save to Excel
df.to_excel('guru_blog.xlsx', index=False)

print("Data saved successfully.")


# In[ ]:




