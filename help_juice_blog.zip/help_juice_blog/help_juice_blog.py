#!/usr/bin/env python
# coding: utf-8

# In[1]:


# importing necessary libraries

import time
import csv
import requests
from time import sleep
from datetime import date
import pandas as pd
from bs4 import BeautifulSoup
from openpyxl import Workbook
import warnings
warnings.filterwarnings("ignore")

# scrapping pages

pages = 1

# connecting the URL for scrapping
url = "https://helpjuice.com/blog?page="

blog = []

page_num = 1

# Create empty lists to store the data
titles = []
authors = []
published_dates = []

# creating soup and requests for accessing the data from the page.
while True:
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    dataa = soup.find_all('div', class_="post-info")

    for data in dataa:
        loc = {}

        title = data.h2.text.strip()
        loc["Title"] = title
        titles.append(title)
        print("Title :", title)

        author_element = data.find('div', class_="author-info")
        author = author_element.strong.text.strip()
        loc["Author"] = author
        authors.append(author)
        print("Author :", author)

        date = author_element.span.text
        loc["Published Date"] = date
        published_dates.append(date)
        print("Published Date:", date)

    # this is for Automated to go for the next pages of blogs to scrape the data.
    next_button = soup.find('a', rel="next")
    if next_button:
        page = next_button['href']
        url = "https://helpjuice.com" + page
        page_num += 1

    else:
        break

# Create a DataFrame using pandas for storing the data into CSV and XLSX format.
df = pd.DataFrame({
    'Title': titles,
    'Author': authors,
    'Published Date': published_dates
})

# Save to CSV
df.to_csv('help_juice_blog.csv', index=False)

# Save to Excel
df.to_excel('help_juice_blog.xlsx', index=False)

print("Data saved successfully.")


# In[ ]:





# In[ ]:




