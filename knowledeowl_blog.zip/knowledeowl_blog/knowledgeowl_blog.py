#!/usr/bin/env python
# coding: utf-8

# In[8]:


import time
import csv
import re
import requests
from time import sleep
from datetime import date
import pandas as pd
from bs4 import BeautifulSoup
from openpyxl import Workbook
import warnings
warnings.filterwarnings("ignore")

pages = 2

url = "https://blog.knowledgeowl.com/blog/categories/all/"

blog = []

titles_list = []
authors_list = []
published_dates_list = []
keywords_list = []

# creating a request

while True:
    
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    data_blog = soup.find_all('div', class_ = "blog-post__wrapper")
    
    
    for data in data_blog:
        loc = {}
        
        title = data.find('h3', class_="blog-post__title").text.strip()
        loc ['title'] = title
        titles_list.append(title)
        print('title:', title)
        
        keyword= data.find('a', class_="blog-post__badge").text.strip()
        loc['keyword']= keyword
        keywords_list.append(keyword)
        print('keyword:', keyword)
        
        author = data.find('p', class_="blog-post__published").a.text.strip()
        loc['author'] = author
        authors_list.append(author)
        print('author:', author)
        
        published_date_element = data.find('p', class_="blog-post__published")
        if published_date_element:
            published_date = published_date_element.span.text.strip()
            loc['published_date'] = published_date
            published_dates_list.append(published_date)
            # Check if the author name is present in the published_date
        if author in published_date:
            published_date = published_date.replace(author, "").strip()
            print('published_date:', published_date)


    next_button = soup.find('a', href="/blog/categories/all/{}/".format(pages))
    if next_button:
        page = next_button['href']
        print("print of page:", page)
        url = "https://blog.knowledgeowl.com" + page
        pages += 1
    else:
        break

        
# Create a DataFrame using pandas for storing the data into CSV and XLSX format.
df = pd.DataFrame({
    'Title': titles_list,
    'Author': authors_list,
    'keyword':keywords_list,
    'Published Date': published_dates_list
})

# Save to CSV
df.to_csv('knowledgeowl_blog.csv', index=False)

# Save to Excel
df.to_excel('knowledgeowl_blog.xlsx', index=False)

print("Data saved successfully.")



# In[ ]:




