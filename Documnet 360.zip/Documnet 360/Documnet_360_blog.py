#!/usr/bin/env python
# coding: utf-8

# In[57]:


import time
import csv
import re
import requests
from time import sleep
from datetime import date
import pandas as pd
from bs4 import BeautifulSoup
from openpyxl import Workbook
import warnings
warnings.filterwarnings("ignore")

pages = 1

url_base = "https://document360.com/blog/page/"

title_list = []
author_list = []
published_date_list = []
keyword_list = []

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
}

while True:
    loc = {}
    response = requests.get(url_base + str(pages), headers=headers)
    soup = BeautifulSoup(response.content, 'html.parser')
    
    # Check if 'd360-blog-list' exists
    data_blog_list = soup.find('div', class_='d360-blog-list')
    if data_blog_list:
        data_blog_thumb = data_blog_list.find('div', class_='d360-post-thumb')
        
        # Check if 'd360-post-thumb' exists
        if data_blog_thumb:
            # Check if 'd360-ratings' exists before decomposing
            if data_blog_thumb.find(class_='d360-ratings'):
                data_blog_thumb.find(class_='d360-ratings').decompose()
            
            data_blogs = data_blog_thumb.find_all('div', class_='d360-card')
            
            for data in data_blogs:
                title = data.h5.text.strip()
                
                all_p_tags = data.find_all('p')
                if len(all_p_tags) > 1:
                    keyword = all_p_tags[0].text.strip()
                    name_date = all_p_tags[1].text.strip()
                    date, name = name_date.split('•', 1)
                    keyword_list.append(keyword)
                    title_list.append(title)
                    author_list.append(name)
                    published_date_list.append(date)

            next_button = soup.find_all('div', class_='nav-links')
            if next_button:
                page = soup.find('span', class_="page-numbers current")
                page_next = page.find_next('a')['href']
                print("Processing page:", pages)
                url = page_next
                pages += 1
            else:
                print("No more pages. Exiting the loop.")
                break
        else:
            print("Error: 'd360-post-thumb' not found.")
            break
    else:
        print("Error: 'd360-blog-list' not found.")
        break
df = pd.DataFrame({
    'Title': title_list,
    'Author': author_list,
    'Published Date': published_date_list,
    'Keyword': keyword_list
})

# Save to XLSX
df.to_excel('document360_blog.xlsx', index=False)

# Save to CSV
df.to_csv('document360_blog.csv', index=False)

print("stored Successfully!!!")


# In[ ]:




